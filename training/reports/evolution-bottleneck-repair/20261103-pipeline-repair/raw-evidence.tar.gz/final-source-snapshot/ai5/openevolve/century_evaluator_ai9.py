# Century AI 9.0 多模块 OpenEvolve 评估适配器（Python ↔ Node）。
#
# 与 AI5 单函数评估器的区别：
#   - 一个程序可包含多个 EVOLVE-BLOCK（每个 = 一个注册模块函数）；
#   - 静态检查/组装/编译/探针全部走 ai5/openevolve/node/*.mjs 多模块管线；
#   - stage2/3 在真实 2–5 人对局中用候选的独立 ESM 决策包控制焦点席位，
#     与冻结冠军同一座位配对比较；主指标 = 焦点席位第一名率增量。
#
# 安全模型（与 AI5 同口径）：
#   - OpenEvolve 生成代码一律视为不可信；所有执行在 macOS Seatbelt 内；
#   - 禁网、禁读用户主目录、只允许写工作区；
#   - 静态检查先行；超时/异常/违例直接淘汰；
#   - 评估器不采信候选自报结果，成绩只由真实对局/探针计算。
#
# 种子纪律：
#   - 真实研究评估使用治理入口预登记的 AI9 screen/deep 开发窗口；
#   - stage2 16 种子（每人 4）、stage3 48 种子（每人 12），互不重叠；
#   - 正式验证池 [900M, 1.06e9) 与本评估器零接触。

import json
import os
import shutil
import subprocess
import sys
import hashlib
import time
from pathlib import Path

AI9_ROOT = Path(__file__).resolve().parent
REPO_ROOT = AI9_ROOT.parent.parent
NODE_DIR = AI9_ROOT / "node"
SANDBOX_TEMPLATE = AI9_ROOT / "sandbox" / "candidate.sb.tmpl"
WORK_ROOT = AI9_ROOT / "work-ai9"
CACHE_ROOT = WORK_ROOT / "cache"
RESULTS_ROOT = AI9_ROOT / "results" / "ai9-evaluations"

# 研究评估种子数量可被无人值守运行显式缩小（必须在报告中记录），
# 默认 16/48 保持不变；数量按人数层（4）对齐，余数丢弃，绝不跨层复用种子。
def _stage_seed_count(env_name: str, default: int) -> int:
    raw = os.environ.get(env_name)
    try:
        value = int(raw) if raw else default
    except ValueError:
        value = default
    value = max(4, value)
    return value - (value % 4)


STAGE2_COUNT = _stage_seed_count("CENTURY_OPENEVOLVE_STAGE2_SEEDS", 16)
STAGE3_COUNT = _stage_seed_count("CENTURY_OPENEVOLVE_STAGE3_SEEDS", 48)
sys.path.insert(0, str(REPO_ROOT / "ai5" / "lib"))
from seed_policy import (generate_unique_seeds, assert_in_block, AI9_OPENEVOLVE_STAGE2_BLOCK,
                         AI9_OPENEVOLVE_STAGE3_BLOCK, AI9_DEV_SCREEN_BLOCK, AI9_DEV_DEEP_BLOCK)


def _stage_seeds(stage, count):
    path = os.environ.get(f"CENTURY_OPENEVOLVE_STAGE{stage}_SEED_FILE")
    if path:
        values = json.loads(Path(path).read_text())
        block = AI9_DEV_SCREEN_BLOCK if stage == 2 else AI9_DEV_DEEP_BLOCK
        if not isinstance(values, list) or len(values) < 8 or len(values) % 4 or len(set(values)) != len(values):
            raise ValueError("阶段种子必须独立、覆盖 2–5 人且每层至少两对")
        for seed in values:
            assert_in_block(seed, block)
        return values
    block = AI9_OPENEVOLVE_STAGE2_BLOCK if stage == 2 else AI9_OPENEVOLVE_STAGE3_BLOCK
    return generate_unique_seeds(count, block, block[0])

STAGE2_SEEDS = _stage_seeds(2, STAGE2_COUNT)
STAGE3_SEEDS = _stage_seeds(3, STAGE3_COUNT)
PLAYER_COUNTS = [2, 3, 4, 5]
FORMAL_WORK_UNITS = 32

SANDBOX_ENV = {
    "PATH": f"{os.path.dirname(os.path.realpath(shutil.which('node') or '/usr/local/bin/node'))}:/usr/bin:/bin:/usr/sbin:/sbin",
    "HOME": str(WORK_ROOT / "home"),
    "TMPDIR": str(WORK_ROOT / "tmp"),
    "LANG": "en_US.UTF-8",
}

_STAGE_TIMEOUT = {1: 300, 2: 2400, 3: 5400}


def _ensure_dirs():
    for p in (WORK_ROOT, CACHE_ROOT, RESULTS_ROOT, WORK_ROOT / "home", WORK_ROOT / "tmp"):
        p.mkdir(parents=True, exist_ok=True)


def _render_sandbox_profile() -> Path:
    profile = (SANDBOX_TEMPLATE.read_text()
               .replace("@WORKROOT@", str(WORK_ROOT))
               .replace("@REPOROOT@", str(REPO_ROOT))
               .replace("@HOME@", str(Path.home())))
    out = WORK_ROOT / "sandbox-rendered.sb"
    out.write_text(profile)
    return out


def _run(cmd, timeout, log_name, cwd=None):
    try:
        return subprocess.run(
            cmd, cwd=str(cwd or WORK_ROOT), env=SANDBOX_ENV,
            capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired as e:
        class _TimedOut:
            returncode = -9
            stdout = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
            stderr = f"TIMEOUT after {timeout}s: {log_name}"
        return _TimedOut()


def _fail(stage, reason, **extra):
    return {
        "combined_score": 0.0,
        "stage_passed": 0.0,
        "failure_stage": stage,
        "failure_reason": str(reason)[:800],
        **extra,
    }


def worst_stratum_penalty(by_player_count):
    """返回 (最差人数, 最差 delta, 惩罚值)。

    分层只读取同一批真实配对对局已有的 byPlayerCount 统计，不新增种子、
    不改变主指标；惩罚用于避免“总体提升但某个 2/3/4/5 人分层明显退化”的候选。
    """
    if not isinstance(by_player_count, dict):
        return None, None, 0.0
    values = []
    for key, item in by_player_count.items():
        if not isinstance(item, dict) or item.get("delta") is None:
            continue
        try:
            values.append((int(key), float(item["delta"])))
        except (TypeError, ValueError):
            continue
    if not values:
        return None, None, 0.0
    worst = min(values, key=lambda pair: pair[1])
    return worst[0], worst[1], 0.20 * max(0.0, -worst[1])


def compute_combined_score(delta_mean, anomaly_rate=0.0, latency_excess=0.0,
                           complexity_excess=0.0, by_player_count=None):
    """主指标 + 原有惩罚 + 最差分人数层惩罚（advisory，不替代正式验证）。"""
    if delta_mean is None:
        return 0.0
    _, _, stratum_penalty = worst_stratum_penalty(by_player_count)
    return (
        0.5
        + 0.5 * float(delta_mean)
        - 1.5 * float(anomaly_rate or 0.0)
        - 0.10 * float(latency_excess or 0.0)
        - 0.05 * float(complexity_excess or 0.0)
        - float(stratum_penalty)
    )


def _stage_impl(program_path: str, stage: int) -> dict:
    _ensure_dirs()
    program_path = str(Path(program_path).resolve())
    profile = _render_sandbox_profile()

    # ---------- stage 1：静态检查 → 组装 → 编译 → 多模块行为探针 ----------
    static_json = WORK_ROOT / "static-ai9.json"
    static = _run([
        "/usr/bin/sandbox-exec", "-f", str(profile), "node",
        str(NODE_DIR / "static_check_modules.mjs"),
        "--program", str(program_path), "--out", str(static_json),
    ], 90, "static-ai9")
    if static.returncode != 0:
        detail = {}
        try:
            detail = json.loads(static_json.read_text())
        except Exception:
            pass
        return _fail("static", detail.get("reason") or static.stderr[-800:] or static.stdout[-400:])
    static_result = json.loads(static_json.read_text())
    modules = static_result["modules"]
    module_ids = [m["id"] for m in modules]
    context_file = os.environ.get("CENTURY_OPENEVOLVE_CONTEXT")
    context = json.loads(Path(context_file).read_text()) if context_file else {}
    if context.get("moduleIds") and sorted(module_ids) != sorted(context["moduleIds"]):
        return _fail("inheritance", "完整模块集合改变")
    for module in modules:
        expected = context.get("lockedModuleHashes", {}).get(module["id"])
        if expected and module["functionSha256"] != expected:
            return _fail("inheritance", "锁定父模块被修改: " + module["id"])
    combined_hash = static_result["combinedSha256"]

    workdir = CACHE_ROOT / combined_hash[:24]
    asm = _run([
        "/usr/bin/sandbox-exec", "-f", str(profile), "node",
        str(NODE_DIR / "assemble_modules.mjs"),
        "--manifest", str(static_json), "--out", str(workdir),
    ], 120, "assemble-ai9")
    if asm.returncode != 0:
        return _fail("assemble", asm.stderr[-800:] or asm.stdout[-400:])

    dist_ai = workdir / "dist" / "js" / "ai.js"
    if not dist_ai.exists():
        (workdir / "package.json").write_text(json.dumps({"type": "module"}))
        tsc = _run([
            "/usr/bin/sandbox-exec", "-f", str(profile), "node",
            str(REPO_ROOT / "web-v1/node_modules/typescript/bin/tsc"),
            "-p", str(workdir / "tsconfig.json"),
        ], 240, "tsc-ai9", cwd=workdir)
        if tsc.returncode != 0:
            return _fail("compile", tsc.stderr[-1200:] or tsc.stdout[-800:], compile_stderr=tsc.stderr[-400:])
    if not dist_ai.exists():
        return _fail("compile", "tsc 成功但未产出 dist/js/ai.js")

    probe_json = WORK_ROOT / "probe-ai9.json"
    probe = _run([
        "/usr/bin/sandbox-exec", "-f", str(profile), "node",
        str(NODE_DIR / "ai9_probe.mjs"),
        "--candidate", str(workdir / "dist/js"),
        "--modules", ",".join(module_ids),
        "--out", str(probe_json),
    ], 180, "probe-ai9")
    if probe.returncode != 0:
        detail = {}
        try:
            detail = json.loads(probe_json.read_text())
        except Exception:
            pass
        return _fail("probe", detail.get("probeErrors") or probe.stderr[-600:] or "probe failed")

    probe_result = json.loads(probe_json.read_text())
    total_source = sum(int(m.get("textLength") or 0) for m in modules)
    stage1_metrics = {
        "combined_score": 1.0,
        "stage_passed": 1.0,
        "static_ok": 1.0,
        "compile_ok": 1.0,
        "probe_ok": 1.0,
        "module_count": float(len(modules)),
        "changed_module_count": float(len(probe_result.get("changedModules") or [])),
        "identical_to_official": 1.0 if probe_result.get("identicalToOfficial") else 0.0,
        "module_mismatches": float(probe_result.get("mismatchCount") or 0),
        "code_complexity": float(total_source),
        "combined_module_hash_head": float(int(combined_hash[:8], 16) / 0xFFFFFFFF),
    }
    if stage == 1:
        return stage1_metrics

    # ---------- stage 2/3：沙箱内真实 2–5 人对局 ----------
    if not os.environ.get(f"CENTURY_OPENEVOLVE_STAGE{stage}_SEED_FILE"):
        return _fail("seed-policy", "真实对局必须通过治理入口提供已登记的开发种子文件")
    seeds = STAGE2_SEEDS if stage == 2 else STAGE3_SEEDS
    seed_list = WORK_ROOT / f"seeds-ai9-stage{stage}.txt"
    seed_list.write_text("\n".join(map(str, seeds)))
    result_json = WORK_ROOT / f"duel-ai9-stage{stage}.json"
    parameter_args = []
    if context.get("parameters"):
        parameter_file = WORK_ROOT / "candidate-parameters.json"
        parameter_file.write_text(json.dumps(context["parameters"]))
        parameter_args = ["--parameters", str(parameter_file)]
    duel = _run([
        "/usr/bin/sandbox-exec", "-f", str(profile), "node",
        str(NODE_DIR / "ai9_duel_runner.mjs"),
        "--candidate", str(workdir / "dist/js"),
        "--seed-list", str(seed_list),
        "--player-counts", ",".join(map(str, PLAYER_COUNTS)),
        "--work-units", str(FORMAL_WORK_UNITS),
        "--mode", "screen" if stage == 2 else "deep",
        "--out", str(result_json),
        *parameter_args,
        *(["--dev-seeds"] if os.environ.get(f"CENTURY_OPENEVOLVE_STAGE{stage}_SEED_FILE") else []),
    ], _STAGE_TIMEOUT[stage], f"duel-ai9-stage{stage}")
    if duel.returncode != 0:
        return _fail("duel", duel.stderr[-800:] or f"duel stage{stage} failed")
    duel_result = json.loads(result_json.read_text())
    stats = duel_result["stats"]

    # 追加保存每次评估，种子/参数不同的相同源码不得覆盖历史证据。
    evidence_root = Path(os.environ.get("CENTURY_OPENEVOLVE_EVIDENCE_DIR", str(RESULTS_ROOT)))
    eval_dir = evidence_root / combined_hash[:12] / str(time.time_ns())
    eval_dir.mkdir(parents=True, exist_ok=True)
    (eval_dir / f"stage{stage}.json").write_text(json.dumps(duel_result, ensure_ascii=False, indent=2))
    (eval_dir / "context.json").write_text(json.dumps({"context": context, "seeds": seeds, "stage": stage, "workUnits": FORMAL_WORK_UNITS}, ensure_ascii=False, indent=2))
    (eval_dir / "modules.json").write_text(json.dumps(static_result, ensure_ascii=False, indent=2))
    (eval_dir / "probe.json").write_text(json.dumps(probe_result, ensure_ascii=False, indent=2))

    anomaly_rate = stats.get("anomalyRate", 1.0)
    first_place = stats.get("firstPlaceDelta") or {}
    delta = first_place.get("ci")
    delta_mean = float(delta["mean"]) if delta else None
    by_player_count = first_place.get("byPlayerCount") or {}
    p95_wall = stats.get("p95WallMs") or 0.0
    # 延迟约束按「单次决策平均耗时」判定（本地推理预算），整局墙钟只作诊断。
    mean_decision = stats.get("meanDecisionMs") or 0.0
    latency_excess = min(1.0, max(0.0, (mean_decision - 300.0) / 300.0))
    complexity_excess = min(1.0, max(0.0, total_source / 12000.0 - 1.0))
    worst_count, worst_delta, stratum_penalty = worst_stratum_penalty(by_player_count)
    combined = compute_combined_score(
        delta_mean, anomaly_rate, latency_excess, complexity_excess, by_player_count,
    )
    # 有限探针相等不能证明真实对局行为相等，更不能覆盖已取得的竞技读数。
    # 探针仍承担执行安全检查；源码原样返回由桥接层单独拒绝。

    return {
        "combined_score": round(combined, 4),
        "stage_passed": 1.0,
        "primary_metric": "pairedFirstPlaceRateDelta",
        "module_count": float(len(modules)),
        "changed_module_count": float(len(probe_result.get("changedModules") or [])),
        "first_place_delta": float(delta_mean) if delta_mean is not None else 0.0,
        "first_place_ci_lower": float(delta["lower"]) if delta else 0.0,
        "candidate_first_rate": float(stats.get("candidateFirstRate") or 0.0),
        "champion_first_rate": float(stats.get("championFirstRate") or 0.0),
        "games": float(stats.get("totalGames", 0)),
        "anomaly_rate": float(anomaly_rate),
        "p95_wall_ms": float(p95_wall),
        "mean_decision_ms": float(mean_decision),
        "code_complexity": float(total_source),
        "pooled_module_hash_head": float(int(combined_hash[:8], 16) / 0xFFFFFFFF),
        "seed_block": float((AI9_DEV_SCREEN_BLOCK if stage == 2 else AI9_DEV_DEEP_BLOCK)[0] // 1_000_000),
        "worst_player_count": float(worst_count) if worst_count is not None else 0.0,
        "worst_player_count_delta": float(worst_delta) if worst_delta is not None else 0.0,
        "stratified_penalty": float(round(stratum_penalty, 4)),
        "by_player_count": json.dumps(by_player_count, ensure_ascii=False),
    }


def _research_artifacts() -> dict:
    """P1.2：把本轮研究简报作为 OpenEvolve artifacts 注入后续提示上下文。
    只读取由 campaign 控制器写下的简报文件；文件缺失时返回空 dict，绝不伪造。"""
    path = os.environ.get("CENTURY_RESEARCH_BRIEF")
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as handle:
            brief = json.load(handle)
    except Exception:
        return {}
    hypotheses = brief.get("hypotheses") or []
    lines = [f"Research brief (unverified) contextHash={brief.get('contextHash')}"]
    for hypothesis in hypotheses:
        lines.append(f"- {hypothesis.get('id')}: {hypothesis.get('statement')}")
        for mechanism in hypothesis.get("mechanisms") or []:
            lines.append(f"  * {mechanism.get('id')}: {mechanism.get('claim')} | prediction: {mechanism.get('prediction')}")
    for failure in brief.get("failures") or []:
        lines.append(f"- observed weakness [{failure.get('status')}] {failure.get('detail')}")
    return {"research_brief": "\n".join(lines), "research_brief_hash": brief.get("contentHash") or ""}


def _wrap(metrics: dict):
    """返回 EvaluationResult，把研究简报放进原生 artifacts 通道。"""
    artifacts = _research_artifacts()
    if not artifacts:
        return metrics
    try:
        from openevolve.evaluation_result import EvaluationResult
        return EvaluationResult(metrics=metrics, artifacts=artifacts)
    except Exception:
        return metrics


def evaluate(program_path: str, cascade_thresholds=None):
    for stage in (1, 2, 3):
        metrics = _stage_impl(program_path, stage)
        if metrics.get("stage_passed") != 1.0:
            return metrics
        if cascade_thresholds and stage < 3 and metrics["combined_score"] < cascade_thresholds[stage - 1]:
            return _wrap(metrics)
    return _wrap(metrics)


def evaluate_stage1(program_path: str):
    return _wrap(_stage_impl(program_path, 1))


def evaluate_stage2(program_path: str):
    return _wrap(_stage_impl(program_path, 2))


def evaluate_stage3(program_path: str):
    return _wrap(_stage_impl(program_path, 3))


if __name__ == "__main__":
    path = sys.argv[1]
    stage = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    result = _stage_impl(path, stage) if stage else evaluate(path)
    print(json.dumps(result, ensure_ascii=False, indent=2))
