// AI9 多模块联合进化程序（父代源码继承）
// 模块：M05:restMultiplier
// 每个 EVOLVE-BLOCK 对应一个模块；不得增删 block、不得改签名。
// 只能使用各模块的 scope 列出的作用域内依赖；禁止 import/eval/网络/文件/进程/
// 随机数/时钟/隐藏牌库字段；函数必须纯且确定性。
// ===== M05 打出与休息调度 =====
// 函数：restMultiplier（ai/evolve/modules.ts）
// 签名：(state, preferred, params)
// 真实决策接线：planner.searchGrade：休息路线惩罚乘子（缺省 1）
// 依赖模块：无
// 作用域内可用依赖：GOLEM_BY_ID、MERCHANT_BY_ID、has、tradeLimit、VALUES、weighted、stockCount、types: AIObservation/Action/AIParameters/EvolveStateView

/* EVOLVE-BLOCK-START */
export function restMultiplier(state: EvolveStateView, preferred: string | null, params: AIParameters): number {
  // 变异：有已打出卡牌时轻微降低休息惩罚（回收循环倾向）。
  return Math.min(2, 1 + (state.played.length > 0 ? 0.15 : 0));
}
/* EVOLVE-BLOCK-END */
