export function restMultiplier(state: EvolveStateView, preferred: string | null, params: AIParameters): number {
  const total = state.hand.length + state.played.length;
  return total ? 0.8906 - .45 * state.played.length / total : 1;
}