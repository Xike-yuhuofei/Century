export function goalPriority(view: AIObservation, goalId: string, params: AIParameters): number {
  // 缺省：目标优先级完全由既有路线评分决定。
  return 1;
}