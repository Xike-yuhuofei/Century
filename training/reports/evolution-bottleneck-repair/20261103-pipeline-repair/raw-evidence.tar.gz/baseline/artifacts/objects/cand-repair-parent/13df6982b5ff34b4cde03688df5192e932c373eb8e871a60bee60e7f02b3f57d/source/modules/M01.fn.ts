export function goalPriority(view: AIObservation, goalId: string, params: AIParameters): number {
  // 变异：按公开魔像分值做温和目标优先级（0.5–2.0）。
  const goal = GOLEM_BY_ID[goalId];
  return goal ? Math.min(2, Math.max(0.5, goal.points / 8)) : 1;
}