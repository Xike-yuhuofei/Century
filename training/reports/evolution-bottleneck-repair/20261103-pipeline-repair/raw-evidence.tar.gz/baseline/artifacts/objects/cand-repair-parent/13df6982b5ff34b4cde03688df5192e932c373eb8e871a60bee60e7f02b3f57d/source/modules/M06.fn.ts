export function endgameBonus(state: EvolveStateView, params: AIParameters): number {
  // 变异：公开名次胜率模型——用公开分数与本路线预计得分估计第一名概率。
  const selfFinal = state.baseScore - state.baseStockPoints + state.gained
    + state.stock.slice(1).reduce((sum, n) => sum + n, 0);
  const rivals = state.standings.filter(s => s.seat !== state.seat);
  if (!rivals.length) return 0;
  let bestProjected = -Infinity;
  for (const rival of rivals) {
    const remaining = Math.max(0, state.claimThreshold - rival.claimed);
    const pace = rival.claimed > 0 ? rival.score / rival.claimed : 6;
    bestProjected = Math.max(bestProjected, rival.score + remaining * pace);
  }
  const margin = selfFinal - bestProjected;
  const winProbability = 1 / (1 + Math.exp(-margin / 8));
  return Math.max(-8, Math.min(8, (winProbability - 0.5) * 16));
}