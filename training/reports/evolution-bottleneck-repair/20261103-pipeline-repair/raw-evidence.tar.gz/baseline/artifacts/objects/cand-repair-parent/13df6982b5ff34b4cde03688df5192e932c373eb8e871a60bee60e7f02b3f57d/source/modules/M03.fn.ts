export function cardEngineValue(card: Merchant, stock: readonly number[], goal: Golem | null): number {
  if (card.kind === 'create') {
    const useful = goal
      ? card.output!.reduce((s, n, c) => s + Math.min(n, Math.max(0, goal.cost[c] - stock[c])) * VALUES[c], 0)
      : 0;
    return weighted(card.output!) * .42 + useful * .22;
  }
  if (card.kind === 'upgrade') return card.steps! * .7;
  const gain = weighted(card.output!) - weighted(card.input!);
  const reachable = has(stock as Stock, card.input!) ? 1 : .35;
  const targetMatch = goal
    ? card.output!.reduce((s, n, c) => s + Math.min(n, goal.cost[c]) * VALUES[c], 0)
    : 0;
  return Math.max(0, gain) * .30 + reachable * .45 + targetMatch * .17;
}