export function restMultiplier(state: EvolveStateView, preferred: string | null, params: AIParameters): number {
  // 缺省：休息成本完全由 params.restWeight 与既有步数惩罚决定。
  return 1;
}