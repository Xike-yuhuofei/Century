// AI9 多模块联合进化程序（父代源码继承）
// 模块：M01:goalPriority / M02:acquisitionValue / M03:cardEngineValue / M05:restMultiplier / M06:endgameBonus
// 每个 EVOLVE-BLOCK 对应一个模块；不得增删 block、不得改签名。
// 只能使用各模块的 scope 列出的作用域内依赖；禁止 import/eval/网络/文件/进程/
// 随机数/时钟/隐藏牌库字段；函数必须纯且确定性。
// === RESEARCH FEEDBACK (advisory only; not reward truth) ===
// Selected modules: M02, M05. Only edit these EVOLVE-BLOCKs.
// Use these hints only to choose which modules and heuristics to change; validate with real paired games; do not hardcode outcomes.
// Editable modules: M02,M05. Preserve every other block byte-for-byte; all blocks are evaluated together.
// ===== M01 魔像目标选择 =====
// 函数：goalPriority（ai/evolve/modules.ts）
// 签名：(view, goalId, params)
// 真实决策接线：planner.choosePlan：每个目标路线期望乘以 goalPriority（缺省 1）
// 依赖模块：无
// 作用域内可用依赖：GOLEM_BY_ID、MERCHANT_BY_ID、has、tradeLimit、VALUES、weighted、stockCount、types: AIObservation/Action/AIParameters/EvolveStateView
// ===== M02 商人卡获取 =====
// 函数：acquisitionValue（ai/evaluator.ts）
// 签名：(state, cardId, preferred, profile, pressure, params, model)
// 真实决策接线：planner: searchGrade/prospectiveFormula 的新卡价值 + champion-guided 冠军基座
// 依赖模块：M03, M04
// 作用域内可用依赖：MERCHANT_BY_ID、GOLEM_BY_ID、VALUES、weighted、stockCount、cloneStock、engineValue、goalGap、stockPotential、keepValue、trimStock、acquisitionRepeatDelta、types: Golem/Stock/PressureModel/AIParameters/EngineModelContext
// ===== M03 生产引擎评估 =====
// 函数：cardEngineValue（ai/knowledge.ts）
// 签名：(card, stock, goal)
// 真实决策接线：knowledge.engineValue -> planner/engine-model/acquisitionValue
// 依赖模块：无
// 作用域内可用依赖：MERCHANT_BY_ID、GOLEM_BY_ID、GOLEM_DECK、MERCHANT_DECK、has、VALUES、weighted、stockCount、cloneStock、types: Merchant/Golem/Stock
// ===== M05 打出与休息调度 =====
// 函数：restMultiplier（ai/evolve/modules.ts）
// 签名：(state, preferred, params)
// 真实决策接线：planner.searchGrade：休息路线惩罚乘子（缺省 1）
// 依赖模块：无
// 作用域内可用依赖：GOLEM_BY_ID、MERCHANT_BY_ID、has、tradeLimit、VALUES、weighted、stockCount、types: AIObservation/Action/AIParameters/EvolveStateView
// ===== M06 终局与胜率决策 =====
// 函数：endgameBonus（ai/evolve/modules.ts）
// 签名：(state, params)
// 真实决策接线：planner.routeGrade：终局路线价值增量（缺省 0；state.standings/baseScore/claimThreshold 提供公开名次与分数）
// 依赖模块：无
// 作用域内可用依赖：GOLEM_BY_ID、MERCHANT_BY_ID、has、tradeLimit、VALUES、weighted、stockCount、types: AIObservation/Action/AIParameters/EvolveStateView

/* EVOLVE-BLOCK-START */
export function goalPriority(view: AIObservation, goalId: string, params: AIParameters): number {
  // 变异：按公开魔像分值做温和目标优先级（0.5–2.0）。
  const goal = GOLEM_BY_ID[goalId];
  return goal ? Math.min(2, Math.max(0.5, goal.points / 8)) : 1;
}
/* EVOLVE-BLOCK-END */

/* EVOLVE-BLOCK-START */
export function acquisitionValue(
  state: { stock: readonly number[]; hand: readonly string[]; played: readonly string[] },
  cardId: string,
  preferred: string | null,
  profile: { engine: number; contest: number },
  pressure: PressureModel,
  params: AIParameters,
  model: EngineModelContext | null = null,
): number {
  // AI7 C2：v2 只追加"重复使用增量"（创造卡可反复产出/升级卡长期作用/
  // 交易卡循环），叠加在冻结的获取估值血统之上——不替换、不放大其他项。
  const withV2 = (value: number): number =>
    params.engineModel === 'v2' && model
      ? value + acquisitionRepeatDelta(cardId, state, preferred, model)
      : value;
  if (params.acquisitionVariant === 'goal-remaining') {
    return withV2(acquisitionValueGoalRemaining(state, cardId, preferred, profile, pressure, params));
  }
  if (params.acquisitionVariant === 'readiness-efficiency') {
    return withV2(acquisitionValueReadinessEfficiency(state, cardId, preferred, profile, pressure, params));
  }
  const card = MERCHANT_BY_ID[cardId];
  if (!card) return 0;
  const current = engineValue(state, preferred);
  const added = { ...state, hand: [...state.hand, cardId] };
  const raw = Math.max(0, engineValue(added, preferred) - current);
  const target: Golem | null = preferred ? GOLEM_BY_ID[preferred] ?? null : null;
  const engine = [...state.hand, ...state.played].map(id => MERCHANT_BY_ID[id]).filter(Boolean);
  const supplied = engine.reduce((a, c) => {
    if (c.output) c.output.forEach((n, i) => { a[i] += n; });
    return a;
  }, [0, 0, 0, 0] as Stock);
  const synergy = card.kind === 'trade'
    ? card.input!.reduce((n, amount, i) => n + Math.min(amount, supplied[i]) * VALUES[i], 0) / (weighted(card.input!) + 1)
    : card.kind === 'create'
      ? engine.filter(c => c.kind === 'trade').reduce((n, c) =>
          n + c.input!.reduce((v, amount, i) => v + Math.min(amount, card.output![i]), 0), 0) * .18
      : .5;
  const goalFit = target && card.output
    ? card.output.reduce((n, amount, i) => n + Math.min(amount, target.cost[i]) * VALUES[i], 0) / (weighted(target.cost) + 1)
    : 0;
  const demand = pressure.mean[cardId] ?? 0;
  const risk = pressure.peak[cardId] ?? 0;
  // 被抢风险与目标契合叠加为紧迫度：越关键且越可能被抢，越值得立刻出手。
  const urgency = 1 + (risk > 0 && goalFit > 0 ? goalFit : 0);
  return withV2(profile.engine * (raw * .6 * params.engineWeight + synergy * 2 * params.synergyWeight + goalFit * 2 * params.goalWeight)
    + profile.contest * params.contestWeight * (demand * .45 + risk * urgency * .55) * .9);
}
/* EVOLVE-BLOCK-END */

/* EVOLVE-BLOCK-START */
export function cardEngineValue(card: Merchant, stock: readonly number[], goal: Golem | null): number {
  if (card.kind === 'create') {
    const useful = goal
      ? card.output!.reduce((s, n, c) => s + Math.min(n, Math.max(0, goal.cost[c] - stock[c])) * VALUES[c], 0)
      : 0;
    return weighted(card.output!) * .42 + useful * .22;
  }
  if (card.kind === 'upgrade') return card.steps! * .7;
  const gain = weighted(card.output!) - weighted(card.input!);
  const reachable = has(stock as Stock, card.input!) ? 1 : .35;
  const targetMatch = goal
    ? card.output!.reduce((s, n, c) => s + Math.min(n, goal.cost[c]) * VALUES[c], 0)
    : 0;
  return Math.max(0, gain) * .30 + reachable * .45 + targetMatch * .17;
}
/* EVOLVE-BLOCK-END */

/* EVOLVE-BLOCK-START */
export function restMultiplier(state: EvolveStateView, preferred: string | null, params: AIParameters): number {
  const total = state.hand.length + state.played.length;
  return total ? 1.15 - .45 * state.played.length / total : 1;
}
/* EVOLVE-BLOCK-END */

/* EVOLVE-BLOCK-START */
export function endgameBonus(state: EvolveStateView, params: AIParameters): number {
  // 变异：公开名次胜率模型——用公开分数与本路线预计得分估计第一名概率。
  const selfFinal = state.baseScore - state.baseStockPoints + state.gained
    + state.stock.slice(1).reduce((sum, n) => sum + n, 0);
  const rivals = state.standings.filter(s => s.seat !== state.seat);
  if (!rivals.length) return 0;
  let bestProjected = -Infinity;
  for (const rival of rivals) {
    const remaining = Math.max(0, state.claimThreshold - rival.claimed);
    const pace = rival.claimed > 0 ? rival.score / rival.claimed : 6;
    bestProjected = Math.max(bestProjected, rival.score + remaining * pace);
  }
  const margin = selfFinal - bestProjected;
  const winProbability = 1 / (1 + Math.exp(-margin / 8));
  return Math.max(-8, Math.min(8, (winProbability - 0.5) * 16));
}
/* EVOLVE-BLOCK-END */
